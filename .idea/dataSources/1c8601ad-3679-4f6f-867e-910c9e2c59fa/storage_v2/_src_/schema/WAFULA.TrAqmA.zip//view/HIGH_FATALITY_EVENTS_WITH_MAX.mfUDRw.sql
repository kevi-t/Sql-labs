create view HIGH_FATALITY_EVENTS_WITH_MAX as
SELECT hfe.EVENT_TYPE, hfe.FATALITIES, hfe.YEAR, max_fatalities.max_fatalities
FROM high_fatality_events hfe
CROSS JOIN (
  SELECT MAX(FATALITIES) AS max_fatalities
  FROM high_fatality_events
) max_fatalities
/

