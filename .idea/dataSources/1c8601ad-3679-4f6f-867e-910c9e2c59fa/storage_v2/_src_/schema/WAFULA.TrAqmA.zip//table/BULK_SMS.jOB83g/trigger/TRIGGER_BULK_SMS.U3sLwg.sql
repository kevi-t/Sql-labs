create trigger TRIGGER_BULK_SMS
    before insert
    on BULK_SMS
    for each row
BEGIN
    SELECT SEQ_BATCH_ID.NEXTVAL INTO :NEW.BATCH_ID FROM DUAL;
END;
/

