create trigger TRIGGER_USERS
    before insert
    on USERS
    for each row
BEGIN
    SELECT SEQ_USER_ID.NEXTVAL INTO :NEW.user_id FROM DUAL;
END;
/

